import {
  BrowserAnimationsModule,
  InjectableAnimationEngine,
  NoopAnimationsModule,
  provideAnimations,
  provideNoopAnimations
} from "./chunk-Z4XJL5UZ.js";
import "./chunk-ERLH4ADR.js";
import "./chunk-NQUZXEUC.js";
import "./chunk-UBVXDGTI.js";
import {
  ANIMATION_MODULE_TYPE
} from "./chunk-EIPX36HT.js";
export {
  ANIMATION_MODULE_TYPE,
  BrowserAnimationsModule,
  NoopAnimationsModule,
  provideAnimations,
  provideNoopAnimations,
  InjectableAnimationEngine as ɵInjectableAnimationEngine
};
//# sourceMappingURL=@angular_platform-browser_animations.js.map
