import { Injectable, PLATFORM_ID, Inject } from '@angular/core';
import { isPlatformBrowser } from '@angular/common';

@Injectable({
  providedIn: 'root'
})
export class ShoppingCartService {
  shopping_cart_items: any[] = [];

  constructor(@Inject(PLATFORM_ID) private platformId: Object) {}

  addProduct = (product) => {
    let items = this.get_shopping_cart_items();
    if (items) {
      items.push(product);
      this.setLocalStorage(items);
    } else {
      this.shopping_cart_items.push(product);
      this.setLocalStorage(this.shopping_cart_items);
    }
  };

  get_shopping_cart_items = () => {
    if (isPlatformBrowser(this.platformId)) {
      const itemsString = localStorage.getItem('shopping_cart');
      return itemsString ? JSON.parse(itemsString) : [];
    }
    return [];
  };

  private setLocalStorage = (items: any[]) => {
    if (isPlatformBrowser(this.platformId) && typeof localStorage !== 'undefined') {
      localStorage.setItem('shopping_cart', JSON.stringify(items));
    }
  };

  getCartLength = () => {
    const items = this.get_shopping_cart_items();
    return items ? this.get_shopping_cart_items().length : 0;
  };

  getTotal = () => {
    const items = this.get_shopping_cart_items();
    return items?.reduce((acc, item) => acc + item.price, 0);
  };

  removerItem = (p) => {
    const items = this.get_shopping_cart_items();
    const index = items.findIndex((item) => item.id == p.id);
    if (index >= 0) {
      items.splice(index, 1);
      this.setLocalStorage(items);
    }
  };
}
